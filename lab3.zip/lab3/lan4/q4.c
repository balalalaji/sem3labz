#include <stdio.h>

int TowerOfHanoi(int n, char source, char dest, char aux)
{
    static int c = 0;
    if (n == 1)
    {
        printf("\nmove disk 1 from rod %c to rod %c", source, dest);
        c++;
    } 
    else
    {
        TowerOfHanoi(n - 1, source, aux, dest);
        printf("\nmove disk %d from rod %c to rod %c", n, source, dest);
        c++;
        TowerOfHanoi(n - 1, aux, dest, source);
    }
    return c;
}

void main()
{
    int n;
    printf("enter number of discs: ");
    scanf("%d", &n);
    printf("moves are: \n");
    int m = TowerOfHanoi(n, 'A', 'B', 'C');
    printf("\nMoves = %d\n", m);
}
