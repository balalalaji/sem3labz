#include <stdio.h>
#include <stdlib.h>
typedef struct
{
	char name[50];
	int roll;
	double cgpa;
}STUDENT;
void read(STUDENT* s,int n)
{
	for(int i=0;i<n;i++)
	{
		printf("Enter Name :");
		scanf("%s",(s+i)->name);
		printf("Enter Roll :");
		scanf("%d",&(s+i)->roll);
		printf("Enter CGPA :");
		scanf("%lf",&(s+i)->cgpa);
		printf("\n");

	}
}
void disp(STUDENT* s,int n)
{
	for(int i=0;i<n;i++)
	{
		printf("Name : %s\nRoll : %d\nCGPA : %lf\n",(s+i)->name,(s+i)->roll,(s+i)->cgpa);
	}
}
void sort(STUDENT *s,int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if((s+i)->roll>(s+j)->roll)
			{
				STUDENT t=*(s+i);
				*(s+i)=*(s+j);
				*(s+j)=t;
			}
		}
	}
}
int main()
{
	int n;
	printf("Enter no. of students :");
	scanf("%d",&n);
	STUDENT *s=(STUDENT*)calloc(n,sizeof(STUDENT));
	printf("\n");
	read(s,n);
	sort(s,n);
	printf("\n");
	disp(s,n);
}