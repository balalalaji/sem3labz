#include<stdio.h>
#include<stdlib.h>
typedef struct Employee{
	char name[50];
	struct DOB	{
		int day;
		int month;
		int year;
	} DOB;
	struct address{
		int housno;
		int zip;
		char state[100];
	}address;
}Employee;
void read ( struct Employee *e)
{	printf("Name: ");
	scanf("%s", e->name);
	printf("Date of birth: ");
	scanf("%d %d %d", &e->DOB.day, &e->DOB.month, &e->DOB.year);
	printf("address (state,house-number, zip code) : ");
	scanf("%s %d %d", e->address.state, &e->address.housno, &e->address.zip);
}
void display(struct Employee *e)
{
	printf("Name: %s\n", e->name);
	printf("Date of Birth: %d/%d/%d\n",e->DOB.day, e->DOB.month, e->DOB.year);
	printf("address: %d, %d, %s\n", e->address.housno, e->address.zip, e->address.state);
	printf("\n");
}
int main()
{
	int i, n;
	struct Employee *e;
	printf("Enter number of employees: ");
	scanf("%d", &n);
	e = (struct Employee*) malloc (n*sizeof(struct Employee));
	for (i=0; i<n; i++)
	{
		read(e+i);
	}	
	for (i=0; i<n; i++)
	{
		display(e+i);
}}