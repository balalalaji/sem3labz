#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	int day;
	int month;
	int year;
} DOB;

typedef struct
{
	int reg_no;
	char name[50];
	char address[50];
} STU_INFO;

typedef struct
{
	char college_name[50];
	char university_name[50];
} COLLEGE;

typedef struct
{
	DOB d;
	STU_INFO in;
	COLLEGE c;
} STUDENT;

void read(STUDENT* s, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("Student %d\n",i+1);
		printf("Enter DATE of birth : ");
		scanf("%d%d%d",&(s+i)->d.day,&(s+i)->d.month,&(s+i)->d.year);
		printf("\nEnter registration number : ");
		scanf("%d",&(s+i)->in.reg_no);
		printf("Enter name : ");
		scanf("%s",(s+i)->in.name);
		printf("Enter address : ");
		scanf("%s",(s+i)->in.address);
		printf("Enter college name : ");
		scanf("%s",(s+i)->c.college_name);
		printf("Enter university name : ");
		scanf("%s",(s+i)->c.university_name);
	}
}

void display(STUDENT* s, int n)
{
	int i;
 	printf("DOB \n Registration \n Name \n Address\n College Name \n University Name\n");

 	for(i=0;i<n;i++)
 	{
 		printf("%d-%d-%d \n %d \n %s \n %s \n %s \n %s\n",(s+i)->d.day,
 			(s+i)->d.month,(s+i)->d.year,(s+i)->in.reg_no,
 			(s+i)->in.name,(s+i)->in.address,
 			(s+i)->c.college_name,(s+i)->c.university_name);
 	}
}

void main()
{
	int n;
	printf("Enter number of students : ");
	scanf("%d",&n);

	STUDENT* s = (STUDENT*) malloc(n*sizeof(STUDENT));

	read(s,n);
	display(s,n);
} 